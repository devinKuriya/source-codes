#include<iostream>
#include<iomanip>
using namespace std;

//prototypes
void function1(int,int, int);
void function2(int, int, int&);
double function3(int,int, int);


int main()
{
int count=0;
int x;//lower bound
int y;//upper bound
char function;//function
int result;//y-x


	cout<<"Please enter a lower bound(positive integer): ";
	cin>>x;

	cout<<"Please enter an upper bound(positive integer): ";
	cin>>y;

	cout<<"\nPlease enter a function(a,b,c): ";
	cin>>function;

	double sum= function3(x,y,count);

	switch(function)
	{
	case('a'):function1(x,y,count) ;
		break;
	case('b'):function2(x,y,result);
		break;
	case('c'): cout<<"The sum is: "<<setprecision(3)<<sum;
		break;
	default:cout<<"Invalid function";

	}

	return 0;
}
//function1 finds multiples of 3 and 7 in the interval of the bounds
void function1(int x, int y, int count)
{

	for(int count=x;(count<=y); count++ )
		if(count%3==0 && count%7==0)
		cout<<count<<"\n";


}
//function2 finds the difference
void function2(int x, int y, int& result)
{
	result=y-x;
	cout<<"The difference between the 2 integers is "<<result;

}
//function3
double function3(int x, int y, int count)
{
	count=0;
	double sum=0;

	for(int count=x; count<=y; count++)
	{
		sum +=(1.0/count);
	}
		return sum;
}



