#include<iostream>
#include<iomanip>
using namespace std;

//prototype
bool isOdd(int);

int main()
{
string x;//name
int count=0;//number of house(s)
int j;
int t;//width
int h;//height
int a;//new width1
int b;//new width2
int i;//used in for loop
int r;//used in for loop
int I;//used in for loop
int R;//used in for loop
char choice;


do
{
	//user enters, name, width of house
	cout<<"Please enter name: ";
	cin>>x;
	cout<<"Welcome "<<x<<", today we will be building a house."<<"\n";

	cout<<"Please enter the width you'd like the house to be(must be an odd number bigger than 1): ";
	cin>>t;

//fucnction isOdd checks if width meets requirements
	for(int c=1; c <= 3; c++)
	{
	if(isOdd(t))
		break;
	cout<<"Please enter a width bigger than 1 that is odd: ";
	cin>>a;
	if(isOdd(a))
    break;
	cout<<"Please enter a width bigger than 1 that is odd: ";
		cin>>b;
	if(isOdd(b))
	break;
	cout<<"Too many invaild tries, program ending now"<<endl;

	return 0;
	}
	//user enters height of house
	cout<<"Please enter the height of the house: ";
	cin>>h;
	cout<<endl;


	//building roof
	for(i=1; i<=(t/2)+1; i++)
	{
		for(r=1; r<=(t-i);r++)
		cout<<" ";

		for(j=1; j<=(2*i)-1; j++)
		cout<<"*";

		cout<<endl;
	}

	//building walls
	for(R=1; R<=h;R++)
	{
		cout<<setw((t/2))<<"|";
		cout<<setfill(' ');

		cout<<setw(t-1);
		cout<<(' ');

		cout<<"|\n";

	}
	//building floor
	cout<<setw((t/2)+1);
	for(I=1;I<=(t); I++)
		{
		cout<<"-";
		}
	cout<<endl;

	//number of houses

	count++;

	//build another house?
	cout<<"Would you like to build another house(Y/N)?";
	cin>>choice;

}while(choice=='Y');


cout<<"Hope you like your "<<count<<" house(s).\n";




return 0;
}


bool isOdd(int x)
 {if ((x%2)==0 && x>1)
	 return false;
else
	return true;
 }
