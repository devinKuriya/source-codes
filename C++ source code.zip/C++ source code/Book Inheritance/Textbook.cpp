

#include "Textbook.hpp"

Textbook::~Textbook()
{
    cout<<"Textbook destructor called"<<endl;
}
Textbook::Textbook():Book()
{
    URL="";
}
Textbook::Textbook(string url,string publ,int nump,string auth,string t,int pub):Book(publ,nump,auth,t,pub)
{
    identifier=4;
    URL=url;
}
void Textbook::seturl(string url)
{
    URL=url;
}
string Textbook::geturl()
{
    return URL;
}
void Textbook::print()
{
    cout<<"URL: "<<URL<<endl<<"Publisher:"<<publisher<<endl<<"Number of Pages:"<<numpages<<endl<<"Id: "<<identifier<<endl<<"Author: "<<author<<endl<<"Title: "<<title<<endl<<"Publication date: "<<pub_date<<endl;
}

