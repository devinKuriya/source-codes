#include "Reference.hpp"

#ifndef Reference_manager_hpp
#define Reference_manager_hpp

#include <stdio.h>

class Refenecemanager: public Reference
{
protected:
    int capacity;
    int numelements;
    int position;
    Reference *arr[];
    
public:
    Refenecemanager(int);
    void printarr();
    bool add(Reference);
    int get(int);
    bool del(int);
    bool search(int);
    
    
    
    
};

#endif /* Reference_manager_hpp */
