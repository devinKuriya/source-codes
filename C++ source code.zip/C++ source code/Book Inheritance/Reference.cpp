
#include "Reference.hpp"

Reference::Reference()
   {
       identifier=1;
       author="";
       title="";
       pub_date=0;
   }
  Reference:: Reference(string auth,string t,int pub)
   {
       identifier=1;
       author=auth;
       title=t;
       pub_date=pub;
   }
   Reference::~Reference()
   {
       cout<<"Reference Destructor called"<<endl;
   }
string Reference::getauthor()
   {
       return author;
   }
string Reference:: gettitle()
   {
       return title;
   }
 int Reference::getpubdate()
   {
       return pub_date;
   }
  int Reference:: getid()
   {
       return identifier;
   }
 void Reference::print()
   {
       cout<<"Id: "<<identifier<<endl<<"Author: "<<author<<endl<<"Title: "<<title<<endl<<"Publication date: "<<pub_date<<endl;
   }
   
