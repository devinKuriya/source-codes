#include "Book.hpp"

#ifndef Textbook_hpp
#define Textbook_hpp

class Textbook: public Book
{
protected:
    string URL;
public:
    Textbook();
    Textbook(string,string,int,string,string,int);
    void seturl(string);
    string geturl();
    ~Textbook();
    void print();
};



#endif /* Textbook_hpp */
