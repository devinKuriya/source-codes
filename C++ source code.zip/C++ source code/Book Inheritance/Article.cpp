
#include "Article.hpp"
Article::Article(string jt,int sp,int ep,string auth,string t,int pub):Reference(auth,t,pub)
{
    identifier=2;
    journaltitle=jt;
    startp=sp;
    endp=ep;
   
}
int Article::getpagenum()
{
    return endp-startp;
}
Article::~Article()
{
    cout<<"Article destructor called"<<endl;
}
void Article::print()
{
    cout<<"Journal Title:"<<journaltitle<<endl<<"Start Page:"<<startp<<endl<<"End Page:"<<endp<<endl<<"Id: "<<identifier<<endl<<"Author: "<<author<<endl<<"Title: "<<title<<endl<<"Publication date: "<<pub_date<<endl;
    
    
}
