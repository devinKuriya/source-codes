#include<iostream>
#include <string>
using namespace std;

#ifndef Reference_hpp
#define Reference_hpp

class Reference
{
protected://will be used in other classes so not private
    int identifier;
    string author;
    string title;
    int pub_date;
    
public:
    Reference();
    
    Reference(string,string,int);
    ~Reference();

    string getauthor();
 
    string gettitle();
 
    int getpubdate();

    int getid();

  virtual void print();//will be overrided in other classes
    
};

#endif /* Reference_hpp */
