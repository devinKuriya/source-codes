#include "Reference.hpp"

#ifndef Article_hpp
#define Article_hpp

class Article:public Reference
{
private://not used in other classes
    string journaltitle;
    int startp;
    int endp;
    
public:
    Article(string,int ,int ,string ,string,int);
    int getpagenum();
    ~Article();
    virtual void print();
};
#endif /* Article_hpp */
