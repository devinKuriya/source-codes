#include "Reference.hpp"

#ifndef Book_hpp
#define Book_hpp

class Book:public Reference
{
protected:
    string publisher;
    int numpages;
    
public:
    Book();
    Book(string,int,string,string,int);
    ~Book();
    void print();
    int getpages();
    void setpub(string);
    string getpub();
    
};

#endif /* Book_hpp */
