//Devin Kuriya 40111954
//Siddhesh Mishra 40094346


#include "Reference_manager.hpp"
#include "Article.hpp"
#include "Textbook.hpp"

int main()
{
 //reference created
    Reference r1("dev","xyz",22);
    cout<<"Reference"<<endl;
    r1.print();
   //article create
    Article a1("Titlej",1,80,"meg","title",25);
    cout<<endl<<"Journal"<<endl;
    a1.print();
    cout<<"Number of Pages: "<<a1.getpagenum()<<endl;
    //book create
    Book b1("Publisher",55,"sid","titlebook",28);
    cout<<endl<<"Book"<<endl;
    b1.print();
    //textbook created
    Textbook tb1("www.url.com","Publisher1",65,"author","textbook",34);
    cout<<endl<<"Textbook"<<endl;
    tb1.print();

    Refenecemanager rm1(3);
    cout<<rm1.add(a1)<<endl;
    cout<<rm1.add(b1)<<endl;
    cout<<rm1.add(tb1)<<endl;
    cout<<rm1.get(2)<<endl;
    cout<<rm1.del(1)<<endl;
    cout<<rm1.search(2)<<endl;
    rm1.printarr();
    
    
    
    return 0;
}
