
#include "Reference_manager.hpp"


Refenecemanager::Refenecemanager(int capacity)
{
*arr = new Reference[capacity];
    for(int i=0;i<capacity;i++)
       {
           arr[i]=nullptr;
       }
}
bool Refenecemanager::add(Reference r)
{
 for(int i=0;i<capacity;i++)
 {
     if(arr[i]!=nullptr)
         continue;
     else
     { arr[i]=&r;
         return true;
     }
 }
    return false;
}
int Refenecemanager::get(int pos)
{
    cout<<arr[pos];
    return 0;
}

bool Refenecemanager::del(int position)
{
    if(position>capacity)
        return false;
    else
    {
    delete arr[position];
    arr[position]=nullptr;
        return true;
    }
}
bool Refenecemanager::search(int id)
{
    Reference *b;
    for(int i=0;i<capacity;i++)
    {
       b=arr[i];
        if(b->getid()==id)
            return true;
    }
    return false;
}
void Refenecemanager::printarr()
{
    for(int i=0;i<capacity;i++)
    {
        cout<<arr[i]<<endl;
    }
}
