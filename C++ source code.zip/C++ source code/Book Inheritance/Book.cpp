

#include "Book.hpp"

Book::Book():Reference()
{
    publisher="";
    numpages=0;
}


Book::Book(string publ,int nump,string auth,string t,int pub):Reference(auth,t,pub)
{
    identifier=3;
    publisher=publ;
    numpages=nump;
}
Book::~Book()
{
    cout<<"Book destructor called"<<endl;
}
void Book::print()
{
    cout<<"Publisher:"<<publisher<<endl<<"Number of Pages:"<<numpages<<endl<<"Id: "<<identifier<<endl<<"Author: "<<author<<endl<<"Title: "<<title<<endl<<"Publication date: "<<pub_date<<endl;
}
int Book::getpages()
{
    return numpages;
}
void Book::setpub(string p)
{
    publisher=p;
}
string Book::getpub()
{
    return publisher;
}
