//Assignment done by:
//Devin Kuriya #40111954
//Siddhesh Mishra #40094356
#include <iostream>
using namespace std;


int main()
{
	char a[5];//roman numeral
	char temp;//temporary assignment
	int x=0;//final result

	cout<<"Please enter a roman numeral(Enter Q to end): "<<endl;
	 for(int i=0;i<5 ;i++)//takes in the roman numeral
	 {
		 cin>>temp;
		 a[i]=temp;
		 if(temp=='Q')
			 break;
		 else
			 a[i]=temp;
	 }

	int b[5]={0,0,0,0,0};//interger array


	 for(int i=0;i<5;i++)//converts roman numeral to individual integers
	 {
		 if(a[i]=='I')
		 	{b[i]=1;}
		 else if(a[i]=='V')
		 { b[i]=5;}
		 else if(a[i]=='X')
			 b[i]=10;
		 else if(a[i]=='L')
			 b[i]=50;
		 else if(a[i]=='C')
			 b[i]=100;
		 else if(a[i]=='D')
			 b[i]=500;
		 else continue;
	 }
	for(int i=0;i<5;i++)//add/subtracts total roman numeral
	{

		if(b[i]<b[i+1])
	 	 {
		 x=b[i+1]-b[i];
		 break;
	 	 }
	 	 else
	 		x+=b[i];

	}
	cout<<"The roman numeral is:"<<x<<"\n";//final result

	return 0;
	}

