#include <iostream>;
using namespace std;

//function main begins execution of program
int main()
{
	int grade;	//number representing students grade

	cout<<"Enter student's grade\n";	//prompt
	cin>> grade;

	if (grade >=90)	// 90 and above
		cout<<"A+";
	else if (85<=grade)	//85 to 89
		cout<<"A";

	else if (80<=grade)	//80 to 84
		cout<<"A-";

	else if (75<=grade)	//75 to 79
		cout<<"B+";

	else if (70<=grade)	//70 to 74
		cout<<"B";

	else if (65<=grade)	//65 to 69
		cout<<"C+";

	else if (60<=grade)	//60 to 64
		cout<<"C";

	else if (55<=grade)	//55 to 59
		cout<<"C-";

	else if (50<=grade)	//50 to 54
		cout<<"D+";

	else if (45<=grade)	//45 to 49
		cout<<"D";

	else if (40<=grade)	//40 to 44
		cout<<"D-";

	else if (grade<40)	// 40 and below
		cout<<"F";

	return 0;

}
