#include<iostream>
using namespace std;

int main()
{

int num1;
int num2;
int num3;

	cout<<"Enter first number";//prompt
	cin>>num1;
	cout<<"Enter second number";//prompt
	cin>>num2;
	cout<<"Enter thrid number";//prompt
	cin>>num3;


	if(num1>num2 && num2>num3)//scenario 1
		{
		cout<<num1<<endl;
		cout<< num2<<endl;
		cout<< num3<<endl;}

	else if(num1>num3 && num3>num2)//scenario 2
		{
		cout<<num1<<endl;
		cout<< num3<<endl;
		cout<< num2<<endl;
		}

	else if(num2>num1 && num1>num3)//scenario 3
		{
		cout<<num2<<endl;
		cout<< num1<<endl;
		cout<< num3<<endl;
		}

	else if(num2> num3 && num3>num1)//scenario 4
	{
		cout<<num2<<endl;
		cout<< num3<<endl;
		cout<< num1<<endl;
	}

	else if(num3>num1 && num1>num2)//scenario 5
	{
		cout<<num3<<endl;
		cout<< num1<<endl;
		cout<< num2<<endl;
	}

	else if(num3>num2 && num2>num1)//scenario 6
	{
		cout<<num3<<endl;
		cout<< num2<<endl;
		cout<< num1<<endl;
	}


	return 0;
}




