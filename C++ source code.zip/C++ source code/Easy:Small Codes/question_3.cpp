#include<iostream>
using namespace std;

int main()

{

	double LIMIT=20;//highest temp in clecius/ end of counter
	double count=1;//start of counter

	cout<<"Celcius"<<"\t""Fahrenheit""\t""Kelvin" <<"\n";//names of lists
	while (count<=LIMIT)
	{

	cout<<count<<"\t"; cout<<((count*(1.8))+32)<<"\t\t"; cout<<(count+273.15)<<"\n";//equations of conversions
	count=count+1;
	}


	return 0;

}
