#include <iostream>
using namespace std;

int main()
{
double num1;
double num2;

cout<<"Enter the first number"<< "\n";//User asked to enter first double
cin>>num1;
cout<<"Enter the second number" <<"\n";//User asked to enter second double
cin>>num2;

cout<<"num1 * num2 = " <<num1 * num2 <<"\n";//multipication of double
cout<<"num1 + num2 = " <<num1 + num2 <<"\n";//addition of double
cout<<"num1 - num2 = " <<num1 - num2 <<"\n";//subtraction of double
cout<<"num1 / num2 = " <<num1 / num2 <<"\n";//divison of double


return 0;
}
