#include<iostream>
using namespace std;

int main()
{

int num;//number under evaluation

	cout<<"Enter number here \n";//prompt
	cin>>num;

	if(num==2)// 2 is a prime number
	cout<<"Number is prime";
	else if(num==3)// 3 is a prime number
	cout<<"Number is prime";
	else if(num==5)// 5 is a prime number
	cout<<"Number is prime";
	else if(num==7)// 7 is a prime number
	cout<<"Number is prime";
	else if(num==11)//11 is a prime number
	cout<<"NUmber is prime";

	else if (num%2==0)//factor of 2
	cout<<"Number is not prime";
	else if (num%3==0)//factor of 3
	cout<<"Number is not prime";
	else if (num%5==0)//factor of 5
		cout<<"Number is not prime";
	else if (num%7==0)//factor of 7
		cout<<"Number is not prime";
	else if(num%11==0)//factor of 11
		cout<<"Number is not prime";
	else cout<<"Number is prime";//if not divisable by one of these numbers, it must be prime


	return 0;

}
